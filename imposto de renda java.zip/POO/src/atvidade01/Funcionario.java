package atvidade01;

public class Funcionario{
	
	private double salario;
	
	
	
	public double receberSalario() {
		
		
		return salario;
	}



	public double getSalario() {
		return salario;
	}



	public void setSalario(double salario) {
		this.salario = salario;
	}
	
}
